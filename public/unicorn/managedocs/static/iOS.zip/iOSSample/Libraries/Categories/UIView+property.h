//
//  NSObject+UIView_.h
//  Footi
//
//  Created by saimushi on 2013/02/04.
//  Copyright (c) 2013年 saimushi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIView (property)

@property NSInteger width;
@property NSInteger height;

@property NSInteger x;
@property NSInteger y;

@end
