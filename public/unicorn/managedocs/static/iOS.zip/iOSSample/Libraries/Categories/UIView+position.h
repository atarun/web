//
//  NSObject+UIView_.h
//  Footi
//
//  Created by saimushi on 2013/02/04.
//  Copyright (c) 2013年 saimushi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIView (position)

- (void) setFullFrame;
- (void) setFrame:(NSInteger)argX :(NSInteger)argY :(NSInteger)argWidth :(NSInteger)argHeight;

@end
