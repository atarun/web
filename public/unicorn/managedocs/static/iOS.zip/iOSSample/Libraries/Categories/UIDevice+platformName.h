#import <UIKit/UIKit.h>
#import "UIDevice+platformName.h"

@interface UIDevice (platformName)

- (NSString *)platformName;

@end