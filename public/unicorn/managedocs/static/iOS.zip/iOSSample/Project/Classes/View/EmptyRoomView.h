//
//  EmptyRoomView.h
//  Sample
//
//  Created by saimushi on 2014/06/09.
//  Copyright (c) 2014年 shuhei_ohono. All rights reserved.
//

#import "common.h"


@interface EmptyRoomView : UIView

@end
