//
//  ChatData.m
//  Withly
//
//  Created by admin on 7/24/13.
//  Copyright (c) 2013 n00886. All rights reserved.
//

#import "ChatData.h"

@implementation ChatData
@synthesize movieurl;

- (id)init
{
    self = [super init];
    return self;
}

@end
