//
//  MainViewController.h
//  Withly
//
//  Created by n00886 on 2012/10/30.
//  Copyright (c) 2012年 n00886. All rights reserved.
//

#import "common.h"
#import "EGORefreshTableHeaderView.h"
#import "SampleModel.h"

@interface MainViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, EGORefreshTableHeaderDelegate, UIScrollViewDelegate>

@end
