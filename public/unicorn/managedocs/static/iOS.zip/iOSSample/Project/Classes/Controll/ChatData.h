//
//  Person.h
//  Withly
//
//  Created by admin on 7/24/13.
//  Copyright (c) 2013 n00886. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChatData : NSObject

@property (nonatomic, strong) NSString *movieurl;

@end
