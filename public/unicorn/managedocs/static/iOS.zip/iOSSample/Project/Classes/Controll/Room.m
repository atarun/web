//
//  Person.m
//  Withly
//
//  Created by admin on 7/24/13.
//  Copyright (c) 2013 n00886. All rights reserved.
//

#import "Room.h"

@implementation Room
@synthesize roomId,roomName,badgeCount,image;
- (id)init
{
    self = [super init];
    return self;
}

@end
